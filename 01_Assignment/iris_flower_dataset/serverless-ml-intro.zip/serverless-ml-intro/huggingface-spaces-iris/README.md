---
title: Iris
emoji: 🐢
colorFrom: purple
colorTo: green
sdk: gradio
sdk_version: 3.5
app_file: app.py
pinned: false
license: apache-2.0
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
