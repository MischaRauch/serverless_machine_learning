---
title: Iris Monitoring
emoji: 💻
colorFrom: blue
colorTo: pink
sdk: gradio
sdk_version: 3.8.2
app_file: app.py
pinned: false
license: apache-2.0
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
